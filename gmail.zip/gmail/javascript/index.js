function show() {
    let sp = document.getElementById('sp').checked
    if (sp) {
        var pass = document.getElementById('pass')
        var cpass = document.getElementById('cpass')
        pass.type = "text"
        cpass.type = "text"
    } else {
        var pass = document.getElementById('pass')
        var cpass = document.getElementById('cpass')
        pass.type = "password"
        cpass.type = "password"
    }
}
function validate() {
    let fname = document.getElementById('fname').value
    let lname = document.getElementById('lname').value
    let pass = document.getElementById('pass').value
    let cpass = document.getElementById('cpass').value

    if (!isNaN(fname) || !fname) {
        console.log("first name should not be empty.")
        return false;
    }
    if (!isNaN(lname) || !lname) {
        console.log("last name should not be empty.")
        return false
    }

    if (!isEmail()) {
        console.log("Please enter email")
        return false
    }
    if (!pass) {
        console.log("password should not be empty.")
        return false
    }

    if (!cpass) {
        console.log('please confirm your password')
        return false
    }else{
        if (cpass == pass) {
            console.log('success')
            return true
        } else {
            console.log("passwords doesn't match.")
            return false
        }
    }
    
}
function isEmail() {
    var email = document.getElementById('email').value
    if (!isNaN(email) || !email) {
        return false
    }
    if (email.split('@').length == 2) {
        email = email.split('@');
        if (email[1].split('.').length == 2) {
            console.log(true)
            return true;
        }
    }
    return false;
} 